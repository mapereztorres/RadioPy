
Welcome to RadioPy : the python package for radio astronomy!


In this folder you will find two other folders named "demo" and
"radiopy". Here we give a little explanation about them.

This software is open-source and is distributed under the license
that can be found in file /radiopy/LICENSE.txt

radiopy
-------
Folder /radiopy is the actual RadioPy package. Opening it would show
all the modules of the package along with its own README.txt.  If you
want to install and use the package the next step is to open and read:
/radiopy/README.txt.


demo 
---- 
Folder /demo contains three examples on how to use RadioPy
package for three cases the user might face. Another important feature
is the file 'radiopy_main.py', an application designed to be used as a
straight-forward tool for processing data. To process your own data
observations you just need to substitute the names of the files where
the data is provided and where the reports should be written.
