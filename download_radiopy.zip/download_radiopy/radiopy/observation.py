#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Wed May 24 14:05:48 2017

Title
-----
Class Observation

Description
-----------

The Class Observation records measured data of frequency and flux for
a single epoch or day measurement. It can also calulate some
hint-parameters from raw data.


Metadata
-------- 
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""
import numpy as np
import radiopy.config as config
import radiopy.global_data as gdata
import radiopy.exceptions as excep
import csv

class Observation:
    """
    This class records data from a day of observations, i.e.
    flux vs frequency lists of data with the respective error bars.
    It is also capable of extracting some basic information from the raw data.
    """

    # -------------------- METHODS --------------------
    
    def __init__(self):
        """
        Constructor of the class Observation that creates empty data lists.
        """
        
        # Frequency in Ghz
        self.freq = list()
        # Flux in mJy
        self.flux = list()
        # Flux uncertainties in mJy
        self.error = list()
        # Day (time) in days
        self.t = float
        
        
    def addPoint(self, freq:float, flux:float, error:float):
        """
        Adds data to the lists.
        
        This method adds a point formed by pair of values frequency (GHz)
        and flux (mJy) with its respective error (mJy).
        
        Parameters
        ----------
        freq : float
            Frequency value (GHz).
        flux : float
            Flux value (mJy).
        error : float
            Flux uncertainty (mJy).
        """

        self.freq.append(freq)
        self.flux.append(flux)
        self.error.append(error)
    
    def setError(self, error:np.ndarray):
        """
        Set the flux uncertainties (mJy)
        
        This method allows to set the error bars from outside the object.
        
        Parameters
        ----------
        error : array[float]
            New error values contained within an array of data (mJy)        
        """
        self.error = error
        
    def setTime(self,t:float):
        """
        Set the age/time value
        
        This method gives value to attribute time "t" (days)
        
        Parameters
        ----------
        t : float
            Lifetime of the SuperNova in days.
        """
        self.t = t
        
        
    def getFreq(self)->np.ndarray:
        """
        Returns a frequency array (GHz).
        
        Returns
        -------
        array[float]
            A frequency array (GHz).
        """
        
        return np.array(self.freq)
        

    def getFlux(self)->np.ndarray:
        """
        Returns a flux array (mJy).
        
        Returns
        -------
        array[float]
            A flux array (mJy).
        """
        
        return np.array(self.flux)
        

    def getError(self)->np.ndarray:
        """
        Returns an array of flux uncertainties (mJy).
        
        Returns
        -------
        array[float]
            Flux errors array (mJy).
        """
        
        return np.array(self.error)
        
    def getTime(self)->float:
        """
        Returns the SN lifetime at the moment of the observation (in days).
        
        Returns
        -------
        float
            Age of the SN in days.
        """
        
        return self.t
        
    def findMaxFluxIndex(self)->int:
        """
        Returns the array index corresponding to the maximun value of flux
        (mJy).
        
        Returns
        -------
        int
            Array index corresponding to the maximun value of observed 
            flux (mJy)

        """
        index = 0
        maxValue=max(self.flux)
        for j in range(0,len(self.flux)):
            if self.flux[j] == maxValue:
                index = j
        return index
        

    def obtainSlope(self, index1:int, index2:int)->float:
        """
        Obtain a straigh-line slope
        
        This method calculates straing-line slope between two points 
        defined by its list-indexes. Slopes are obtained for logarithmic scale.
        
        Parameters
        ----------
        index1 : int
            List-index (either freq and flux) for the initial point.
        index2 : int
            List-index (both freq and flux) for the final point
            
        Returns
        -------
        alpha : float
            Slope of the graph at logarithmic scale
        p : float 
            Exponent of the power-law distribution of electrons. p = 2*alpha + 1
            
        Raises
        ------
        EqualIndexesError
            At method obtainSlope(index1,index2) the indexes cannot be equal.
            Exception is rised otherwise.
        """

        num = len(self.getFlux())
        if index1 > index2:
            intermediate = index1
            index1 = index2
            index2 = intermediate
        if index1 < 0:
            index1 = 0
        if index2 >= num:
            index2 = num-1
        if index1 == index2:
            raise excep.EqualIndexesError('Indexes cannot be equal')
        else:
            alpha = ((np.log(self.flux[index2])-np.log(self.flux[index1]))/
                (np.log(self.freq[index2])-np.log(self.freq[index1])))
            p = 2*abs(alpha)+1
            return alpha, p
            
            
    def readEpochCSV(self,name_CSV:str):
        """
        Reads data for a single epoch from a .csv file.
        
        This method is capable of reading data from a .csv for a single epoch,
        i.e. a set of flux (mJy) vs. frequency (GHz) data taken at approximately
        the same time. Those data are recorded in an instance of class
        Observation.
        
        Parameters
        ----------
        name_CSV : str
            A string containing the name of the file the method has to read.
            The name should be written between quotation marks and the
            extension should be specified. Example: 'myfile.csv'
        """
        header = config.SNConfig.numRowsHeader
        
        f = open(name_CSV, 'r')
        reader = csv.reader(f)
        
        #METADATA ROWS
        gdata.GlobalData.title = next(reader)[1]
        gdata.GlobalData.authors = next(reader)[1]
        gdata.GlobalData.organization = next(reader)[1]
        gdata.GlobalData.eventName = next(reader)[1]
        gdata.GlobalData.eventStartDate = next(reader)[1]
        distanceStr = next(reader)[1]
        gdata.GlobalData.eventDistance = float(distanceStr)
        distanceErrStr = next(reader)[1]
        gdata.GlobalData.eventDistanceErr = float(distanceErrStr)
        gdata.GlobalData.measuringEquipment = next(reader)[1]
        
        rownum = 8
        for row in reader:
            # Save as many rows as 'header' indicates
            # Then
            if rownum >= header:
                if rownum == header:
                    self.setTime(float(row[0]))
                # csv row-list error treatment
                noTreatRow = row
                if noTreatRow[3] == '':
                    noTreatRow[3] == 0
                if noTreatRow[1] == '' or noTreatRow[2] == '':
                    print('Row ',rownum,' deleted - missing point')
                else:
                    for j in range(0,len(noTreatRow)):
                        noTreatRow[j] = float(noTreatRow[j]) 
                    # Add data to the Observation
                    self.addPoint(noTreatRow[1],noTreatRow[2],noTreatRow[3])
            rownum = rownum + 1
        
        f.close()
