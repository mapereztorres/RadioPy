#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Wed May 31 03:28:37 2017

Title
-----
Class Report

Description
-----------
The Class Report creates files containing the results of performing a
fitting for the Super Nova data using the SSA model. It can generate
html and PDF reports.

Installation
------------
This module depends on python-pdfkit: 
    https://pypi.python.org/pypi/pdfkit

To install the pdfkit:
    pip install pdfkit
    
This module requires an external installation of wkhtmltopdf, which 
can be found at:
    https://wkhtmltopdf.org/
    
A binary installer is available for Windows

Ubunty/Debian installation example:
    sudo apt-get install wkhtmltopdf
    
After installation if necessary add the bin folder of wkhtmltopdf
to the PATH. 
    Windows example: 
        Control Panel -> System and Security -> System -> 
        Advanced system settings -> Environment variables
        Edit the PATH variable to add the wkhtmltopdf\\bin folder. Its
        name will be something like:
            c:\\Program Files\\wkhtmltopdf\\bin
    Example in Linux: 
        Usually wkhtmltopdf will be installed at /usr/bin, a directory that
        is already in the PATH by default. If that was not the case, add a
        line to the .bashrc file in the user's folder to add the
        wkhtmltopdf\\bin folder to the PATH. 
        This will be something like:
            export PATH=$PATH:/usr/bin/wkhtmltopdf/bin

Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""

import pdfkit
import os
import radiopy.global_data as gdata
import radiopy.config as config
import radiopy.exceptions as excep
import radiopy.result_sequence as rstseq
import radiopy.result as rst

class Report:
    """
    The Class Report creates files containing the results of
    performing a fitting for the Super Nova data using the SSA model.

    """
    
    @staticmethod
    def infoEpoch(fitResult:rst.Result):
        """
        This method displays on the screen the data recorded within a 
        Result instance.
        
        Parameters
        ----------
        fitResult : Result
            An instance of class Result. This instance should be a
            definitive version including both the fitted values and
            the physical information. Thus, with no None-value
            attributes.
        """

        fitParams = fitResult.getFitting()
        fitError = fitResult.getFittingErr()
        fitGood = fitResult.getFittingGoodness()
        physParams = fitResult.getPhysParams()
        physErr = fitResult.getPhysParamsErr()
        print('Time = ',fitResult.getTime(),' (days)')
        print('Distance = ',gdata.GlobalData.eventDistance,' +- ',
              gdata.GlobalData.eventDistanceErr,' (Mpc)')
        print(' ')
        print('Fitting parameters -')
        if config.SNConfig.enableFixedP:
            print('Exponent p = ',fitParams['p'])
        else:
            print('Exponent p = ',fitParams['p'],' +- ',fitError['pErr'])
        print('Flux st = ',fitParams['st'],' +- ',fitError['stErr'],' (mJy)')
        print('Frequency vt = ',fitParams['vt'],' +- ',fitError['vtErr'],
              ' (GHz)')
        print(' ')
        print('Fitting Goodness - ')
        print('Reduced chi-square per degree of freedom rChiSq = ',
              fitGood['rChiSq'])
        print('Error bar correction factor: ',fitGood['errorCorrFactor'])
        print(' ')
        print('Physical parameters -')
        print('Radious R = ',physParams['r']/1e15,' +- ',physErr['rErr']/1e15,
              ' (1e15 cm)')
        print('Magnetic Field B = ',physParams['b'],' +- ',physErr['bErr'],
              ' (G)')
        print('Circumstellar density A = ',physParams['a'],' +- ',
              physErr['aErr'],' (5e-11 g cm-1)')
    
    
    @staticmethod    
    def _htmlListItem(name:str, value:str)-> str:
        """
        Return a string containing an html list item with name and value.
        
        The 'name' is tagged <strong>.
        
        Parameters
        ----------
        name : str
            Label for the list item. Is tragged as <strong> (bold).
        value : str
            Item of the list.
        
        Returns
        -------
        str
            Combination of label + list item in html language.
        """

        return '    <li><strong>'+name+':</strong> '+value+'</li>\n'
        
    
    @staticmethod
    def _htmlEpoch(fitResult, epochIndex:int, figureType: str,
                   sizeSpec:str)->str:
        """
        Returns an html report of the epoch with index epochIndex.
        
        Parameters
        ----------
        fitResult : Result
            The fitted Result for the epoch to report.
        epochIndex : int
            Index of the ObservationSequence or the ResultSequence to be
            added to the html report.
        figureType : str
            The type of the figure. It should be 'png' or 'svg'
        sizeSpec : str
            The size specification to be used for images 
            
        Returns
        -------
        htmlDescr : str
            An htlm string containing all information regarding the study of
            a single Epoch. That includes a graphic plot of the fitting along
            with the results.
        """

        # The day since the start of the event corresponds to the day parameter.
        day = fitResult.getTime()
        fitParams = fitResult.getFitting()
        fitError = fitResult.getFittingErr()
        fitGood = fitResult.getFittingGoodness()
        physParams = fitResult.getPhysParams()
        physErr = fitResult.getPhysParamsErr()
        d = [gdata.GlobalData.eventDistance,gdata.GlobalData.eventDistanceErr]
        distanceStr = str(d[0])+' &plusmn; '+str(d[1])
        pStr = ("{0:.3f}".format(fitParams['p'])+' &plusmn; '+
                "{0:.3f}".format(fitError['pErr']))
        stStr = ("{0:.3f}".format(fitParams['st'])+' &plusmn; '+
                 "{0:.3f}".format(fitError['stErr']))
        vtStr = ("{0:.3f}".format(fitParams['vt'])+' &plusmn; '+
                "{0:.3f}".format(fitError['vtErr']))
        
        rStr = ("{0:.3f}".format(physParams['r']/1e15)+' &plusmn; '+
                "{0:.3f}".format(physErr['rErr']/1e15))
        bStr = ("{0:.3f}".format(physParams['b'])+' &plusmn; '+
                "{0:.3f}".format(physErr['bErr']))
        aStr = ("{0:.3f}".format(physParams['a'])+' &plusmn; '+
                "{0:.3f}".format(physErr['aErr']))
                           
        
        epochNum = epochIndex+1 #to start with number 1
        
        figurePath = config.SNConfig.figurePath
        
        htmlDescr= '    <h3>2.'+str(epochNum)+'. Day '+str(day)+'</h3>\n'
        htmlDescr+=('    <img  src="../'+figurePath+'epoch'+str(epochNum)+
                    '.'+figureType+'" alt="flux vs frequency fit for epoch '+
                    str(epochNum)+'"\n'+sizeSpec+'>\n<ul>')
        htmlDescr+=Report._htmlListItem('Time (days)',str(day))
        htmlDescr+=Report._htmlListItem('Distance (Mpc)',distanceStr)
        if config.SNConfig.enableFixedP:
            htmlDescr+=Report._htmlListItem('Exponent p',
                                            "{0:.3f}".format(fitParams['p']))
        else:
            htmlDescr+=Report._htmlListItem('Exponent p',pStr)
        htmlDescr+=Report._htmlListItem('Flux st (mJy)',stStr)
        htmlDescr+=Report._htmlListItem('Frequency vt (GHz)',vtStr)
        htmlDescr+=Report._htmlListItem('Chi-square per degree of freedom',
                                "{0:.3f}".format(fitGood['rChiSq']))
        htmlDescr+=Report._htmlListItem('Error bar correction factor',
                                "{0:.3f}".format(fitGood['errorCorrFactor']))
        htmlDescr+=Report._htmlListItem('Radious R (1e15 cm)',rStr)
        htmlDescr+=Report._htmlListItem('Magnetic field B (G)',bStr)
        htmlDescr+=Report._htmlListItem('Circumstellar density A '
                                +'(5e-11 g cm-1)',aStr)
        htmlDescr+='</ul>\n'
        return htmlDescr
        
    
    @staticmethod
    def _htmlHeaderItem(item:str)->str:
        """
        Return an html table header containing  an item.
        
        Parameters
        ----------
        item : str
            A header for the html table.
            
        Returns
        -------
        str
            The html table header.
        """

        return '    <th>'+item+'</th>\n'
        
        
    @staticmethod
    def _htmlTableItem(value:float)->str:
        """
        Return an html table item containing value.
        
        Parameters
        ----------
        value : float
            A data that must appear in the html table.
        
        Returns
        -------
        str
            An html string containing the value.
        """

        return '    <td>'+"{0:.3f}".format(value)+'</td>\n'
        

    @staticmethod
    def _htmlTableItemWithError(value:float, error:float)->str:
        """
        Return an html table item containing value plus minus error.
        
        
        Parameters
        ----------
        value : float
            A data that must appear in the html table.
        error : float
            The uncertainty of such data.
        
        Returns
        -------
        str
            An html string containing the value plus minus its error.
        """
        return ('    <td>'+"{0:.3f}".format(value)+' &plusmn; '+
                "{0:.3f}".format(error)+'</td>\n')
        


    @staticmethod
    def createHTMLReport(resultSeq:rstseq.ResultSequence, file_name:str, 
                         figureType:str):
        """Creates an html report for a sequence of results stored in an
        instance of ResultSequence.
        
        The reports are placed in files file_name.html and file_name.pdf at
        a folder defined by sn_config.SNConfig.reportPATH.
        
        Parameters
        ----------
        resultSeq : ResultSequence
            A filled-in version of an instance of class
            ResultSequence.  Contains a list of complete fitted
            Results, i.e., with both fitted value and physical
            information results.
        file_name : str
            String containing the name of the resulting report-file.
        figureType : str
            String containing the figure type. It should be 'png' or 'svg'
        
        Raises
        ------
        FolderDoesNotExistError
            The figures folder does not exist.
        """
        
        reportPath = config.SNConfig.reportPath
        figurePath = config.SNConfig.figurePath
        
        # Check for the existence of the figures folder and throw exception 
        # if not
        if not os.path.exists(figurePath):
            raise excep.FolderDoesNotExistError(figurePath+' does not exist')
    
        # Check for existence of reports folder and create it if necessary
        if not os.path.exists(reportPath):
            os.makedirs(reportPath)
            
        # Check for the existence of CSS file and write it if necessary
        if not os.path.isfile(reportPath+'radiopy-css.css'):
            css_contents="""
            body {
                background-color: ghostwhite;
                font-family: 'Abel', sans-serif;
                font-size: 16px;
                color: #27334A;
            }
            
            h1, h2, h3 {
            	font-family: 'Abel', sans-serif;
            	font-weight: 400;
            	color: #305E5E;
            }
            
            h1 {
            	padding-bottom: 20px;
            	padding-top: 20px;
            	font-size: 4em;
            }
            
            h2 {
            	padding-top: 10px;
            	padding-bottom: 10px;
            	font-size: 2.8em;
            }
            
            h3 {
            	padding-bottom: 10px;
            	padding-top: 10px;
            	font-size: 1.6em;
            }
            
            p, ul, ol {
            	margin-top: 0;
            	line-height: 150%;
            }
            
            p, ol {
            }
            
            ul, ol {
                list-style-type:none;
            }
            
            a {
            	color: #DC483E;
            }
            
            img {
            	border: 1px solid #D9D9D9;
            	padding: 4px;
                    margin: 16px;
            }
            
            strong {
            	color: #1C0070;
            	font-weight: bold;	
            }
            
            table, th, td {
               border: 1px solid #778899;
               padding: 6px;
            }
            
            table {
                border-collapse: collapse;
            }
            
            th {
                color: white;
                background-color: midnightblue;
                text-align: center;
                font-family: "Times New Roman", Times, serif;
                font-size: 16px;
            }
            
            td {
                text-align: right;
                font-size: 15px;
            }
            """    
            # write the css contents into a file
            with open(reportPath+'radiopy-css.css', 'w') as text_file:
                text_file.write(css_contents) 
    
                
        # Produce an html report in a String
        html_header="""
        <!DOCTYPE html>
        <html>
        <head>
          <title>RadioPy Report</title>
          <link rel="stylesheet" type="text/css" href="radiopy-css.css">
        </head>
        """
        
        html_section1="""
        <body>
        
        <h1>RadioPy Report</h1>
        
        <p>This report was generated with the RadioPy python package for
          radio astronomy: <url> </url></p>
        
        <h2>1. General Data</h2>
        
        <ul>
        """
        
        # General data
        title = gdata.GlobalData.title
        author = gdata.GlobalData.authors
        event = gdata.GlobalData.eventName
        start = gdata.GlobalData.eventStartDate
        dist = str(gdata.GlobalData.eventDistance)
        distErr = '&plusmn;'+str(gdata.GlobalData.eventDistanceErr)
        equipment = gdata.GlobalData.measuringEquipment
        
        html_section1+=Report._htmlListItem('Title',title)
        html_section1+=Report._htmlListItem('Author/s',author)
        html_section1+=Report._htmlListItem('Name of event',event)
        html_section1+=Report._htmlListItem('Start date',start)
        html_section1+=Report._htmlListItem('Distance (Mpc)',dist)
        html_section1+=Report._htmlListItem('Uncertainty on the distance (Mpc)',
                                            distErr)
        html_section1+=Report._htmlListItem('Measuring equipment',equipment)
        html_section1+="""
        </ul>
        """

        # size specification for the figures in the report
        imageWidth = config.SNConfig.figureWidth
        imageHeight = config.SNConfig.figureHeight
        sizeSpec=' width="'+str(imageWidth)+'"'
        if figureType=='png':
           sizeSpec+=' height="'+str(imageHeight)+'"'
        
        html_section2="""
        <h2>2. Study of the different epochs</h2>
        
        
        <p>This study contains the model fits for flux vs frequency
           for the different epochs.
        </p>
        """
        
        numEpochs = resultSeq.getNumResults()
        days = resultSeq.getTimeList()
        
        for i in range(numEpochs):
            html_section2+=Report._htmlEpoch(resultSeq.getResult(i),i,
                                             figureType,sizeSpec)
        
        html_section3="""
        <h2>3. Study of the observation sequence</h2>
        
        <h3>3.1. Table: SSA model fits</h3>
        
         <table>
          <tr>
        """
        
        html_section3+=Report._htmlHeaderItem('Day')
        html_section3+=Report._htmlHeaderItem('Exponent p')
        html_section3+=Report._htmlHeaderItem('Flux S<sub>&tau;</sub> (mJy)')
        html_section3+=Report._htmlHeaderItem(
            'Frequency &nu;<sub>&tau;</sub> (GHz)')
        html_section3+=Report._htmlHeaderItem('Radious R (1e15 cm)')
        html_section3+=Report._htmlHeaderItem('Magnetic field B (G)')
        html_section3+=Report._htmlHeaderItem(
            'Circumstellar density A \n(5e-11&middot;g&middot;cm<sup>-1</sup>)')
    
        pList = resultSeq.getPList()
        stList = resultSeq.getStList()
        vtList = resultSeq.getVtList()
        rList = resultSeq.getREvol()[0]
        bList = resultSeq.getBEvol()[0]
        aList = resultSeq.getAEvol()[0]
    
        pErrList = resultSeq.getPList()
        stErrList = resultSeq.getStErrList()
        vtErrList = resultSeq.getVtErrList()
        rErrList = resultSeq.getREvol()[1]
        bErrList = resultSeq.getBEvol()[1]
        aErrList = resultSeq.getAEvol()[1]

        rSlope = "{0:.3f}".format(resultSeq.getREvol()[2])
        bSlope = "{0:.3f}".format(resultSeq.getBEvol()[2])
        aSlope = "{0:.3f}".format(resultSeq.getAEvol()[2])

        rConst = "{0:.3f}".format(resultSeq.getREvol()[3]/1e15)+' 1e15'
        bConst = "{0:.3f}".format(resultSeq.getBEvol()[3])
        aConst = "{0:.3f}".format(resultSeq.getAEvol()[3])
        
        pAvg = resultSeq.getPAvg()
        pAvgStr = ("{0:.3f}".format(pAvg[0])+' &plusmn; '+
                   "{0:.3f}".format(pAvg[1]))
 
        for i in range(numEpochs):
            html_section3+="""
            </tr>
            <tr>
            """
            html_section3+=Report._htmlTableItem(days[i])
            if config.SNConfig.enableFixedP:
                html_section3+=Report._htmlTableItem(pList[i])
            else:
                html_section3+=Report._htmlTableItemWithError(pList[i],
                                                              pErrList[i])
            html_section3+=Report._htmlTableItemWithError(stList[i],
                                                          stErrList[i])
            html_section3+=Report._htmlTableItemWithError(vtList[i],
                                                          vtErrList[i])
            html_section3+=Report._htmlTableItemWithError(rList[i]/1e15,
                                                          rErrList[i]/1e15)
            html_section3+=Report._htmlTableItemWithError(bList[i],bErrList[i])
            html_section3+=Report._htmlTableItemWithError(aList[i],aErrList[i])
            
        html_section3+="""
          </tr>
        </table> 
        """
        html_section3+=Report._htmlListItem('Average exponent p of all epochs',
                                            pAvgStr)
        html_section3+="""
        
        
        <h3>3.2. Time evolution of physical parameters</h3>
        
        <h4>Radious (cm)</h4>
        
        <img  src="../"""
        html_section3+=figurePath
        html_section3+=('r_time_evol.'+figureType+
                        '" alt="time evolution of R"\n'+sizeSpec+'>)\n')
        
        html_section3+='    <li>Adjustment: R = m*t + b</li>\n'
        html_section3+=Report._htmlListItem('R: Slope m',rSlope)
        html_section3+=Report._htmlListItem('R: Constant b',rConst)
        html_section3+="""<h4>Magnetic field (G)</h4>
        
        <img  src="../"""
        html_section3+=figurePath
        html_section3+=('b_time_evol.'+figureType+
                        '" alt="time evolution of B"\n'+sizeSpec+'>)\n')

        html_section3+='    <li>Adjustment: B = m*t + b</li>\n'
        html_section3+=Report._htmlListItem('B: Slope m',bSlope)
        html_section3+=Report._htmlListItem('B: Constant b',bConst)
        html_section3+="""<h4>Circumstellar density (5e-11&middot;g&middot;
        cm<sup>-1</sup>)
        </h4>
        
        <img  src="../"""
        html_section3+=figurePath
        html_section3+=('a_time_evol.'+figureType+
                        '" alt="time evolution of A"\n'+sizeSpec+'>)\n')

        html_section3+='    <li>Adjustment: A = m*t + b</li>\n'
        html_section3+=Report._htmlListItem('A: Slope m',aSlope)
        html_section3+=Report._htmlListItem('A: Constant b',aConst)
        html_section3+="""
        </body>
        </html> 
        """    
        
        # write the html string into a file
        html_report=html_header+html_section1+html_section2+html_section3
        with open(reportPath+file_name+'.html', 'w') as text_file:
            text_file.write(html_report) 
    
    @staticmethod
    def createPDFReport(resultSeq:rstseq.ResultSequence, file_name:str):
        """
        Creates a pdf report from a sequence of results contained in an 
        instance of ResultSequence.
        
        The report is placed in file file_name.pdf at a folder defined
        by sn_config.SNConfig.reportPATH.  An intermediate HTML file
        called html_to_pdf.html is also created and then removed
        
        Parameters
        ----------
        resultSeq : ResultSequence
            A filled-in version of an instance of class
            ResultSequence.  Contains a list of complete fitted
            Results, i.e., with both fitted value and physical
            information results.
        file_name : str
            String containing the name of the resulting report-file.
        
        Raises
        ------
        FolderDoesNotExistError
            The figures folder does not exist.

        """
        
        reportPath = config.SNConfig.reportPath
        figurePath = config.SNConfig.figurePath

        #create HTML report using png figures, because the conversion
        #of svg figures into the pdf report leaves incomplete figures        
        Report.createHTMLReport(resultSeq,'html_to_pdf','png')

        # convert the hmtl file into a pdf file
        try:
            pdfkit.from_file(reportPath+'html_to_pdf'+'.html',
                             reportPath+file_name+'.pdf')
        except IOError as e:
            print('There was the following error while converting the '+
                  'report to pdf:')
            print(e)
            print()
            print('This can be caused by not having properly set the PATH '+
                  'environment variable to find wkhtmltopdf,')
            print('or because the pdf file was already opened by a pdf viewer,')
            print('or because some of the figures were not found in folder '+
                  figurePath)
            
        #remove intermediate html file
        os.remove(reportPath+'html_to_pdf'+'.html')
