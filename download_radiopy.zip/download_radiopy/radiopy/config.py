#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 24 16:01:17 2017

Title
-----
Class SNConfig

Description
-----------
The Class SNConfig contains different constants and settings with default 
values used by other modules of the package. Its purpose is to facilitate 
changing those values in order to customize the model regarding different
situations the user might like to face.

Metadata
-------- 
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt
"""

class SNConfig:
    """
    The Class SNConfig contains different constants and settings with default 
    values used by other modules of the package. Its purpose is to facilitate 
    changing those values in order to customize the model regarding different
    situations the user might like to face.
    
    Attributes
    ----------
    numRowsHeader : int
        Number of rows corresponding to the header of the .csv file.
    enableErrCorr : boolean
        This boolean allows establishing whether the error bars should be
        corrected in order to get a better fitting with reduced chi-square
        per degree of freedom close to 1.
    enableFixedP : boolean
        This boolean allows establishing whether the fitting algorithm 
        (class SNFit) should fix parameter p or set it free.
    fixedP : float
        Default value for fixed p exponent of the power-law distribution
        of electrons.
    fitAccuracy : float
        This parameter sets the accuracy factor for the root binary search. It
        might be useful to change it if fitting does not behave properly.
    alpha : float
        Alpha is the ratio of electron to magnetic energy densities.
        Assuming equipartition alpha = 1.
    fillFactor : float
        The filling factor of emmitting material gives an idea of the how
        many electrons of the total material conttribute to the emission. 
        We assume it to be 0.5 as found by Bartel+ (2002) for SN 1993J.
    eB : float
        eB is the converted fraction of kinetic to magnetic energy density.
        It was found to give consistent results with value eB = 0.1 at
        Krauss+ (2012).
    figurePath : str
        String containing the path where the figures will be saved.
    reportPath : str
        String containing the path where the reports will be saved.
    figureWitdth : int
        The width (in pixels) of the figures that will appear in the report.
    figureHeight : int
        The height (in pixels) of the figures that will appear in the report.
        Height is not used for svg graphs since an aspect relation is kept. 
    plotEpochAxeX : array[float]
        A two-values array that defines the abscissae 'x' axis for a single 
        epoch plot.
    plotEpochAxeY : array[float]
        A two-values array that defines the ordinates 'y' axis for a single 
        epoch plot.
    """
    
    # -------------------- ATTRIBUTES --------------------  
    
    # Number of rows corresponding to the header of the .csv file. 
    numRowsHeader = 9
        
    # This boolean allows establishing whether the error bars should be
    # corrected in order to get a better fitting with reduced chi-square
    # per degree of freedom close to 1.
    enableErrCorr = True 
    
    # This boolean allows establishing whether the fitting algorithm 
    # (class SNFit) should fix parameter p or set it free.
    enableFixedP = False
    
    # Default value for fixed p exponent of the power-law distribution of 
    # electrons.
    fixedP = 2.8
    
    # This parameter sets the accuracy factor for the root binary search. It
    # might be useful to change it if fitting does not behave properly.
    fitAccuracy = 0.0001
    
    # Alpha is the ratio of electron to magnetic energy densities.
    # Assuming equipartition alpha = 1.
    alpha = 1
    
    # The filling factor of emmitting material gives an idea of the how
    # many electrons of the total material conttribute to the emission. 
    # We assume it to be 0.5 as found by Bartel+ (2002) for SN 1993J. 
    fillFactor = 0.5
    
    
    # eB is the converted fraction of kinetic to magnetic energy density.
    # eB was found to give consistent results with value eB = 0.1 at
    # Krauss+ (2012).
    eB = 0.1
    
    # Path where figures will be saved.
    figurePath = 'figures/'
    
    # Path where the reports will be saved.
    reportPath = 'reports/'
    
    # Width and Height (in pixels) of the plots presented in the report.
    # Height is not used for svg graphs since an aspect relation 
    # is preserved.
    figureWidth = 600
    figureHeight = 400

    # A couple of arrays defining the axes for the plots of a single epoch.
    plotEpochAxeX = [1,100]
    plotEpochAxeY = [0.1,15]
    
