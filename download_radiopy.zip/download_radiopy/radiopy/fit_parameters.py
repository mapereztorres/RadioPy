#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Wed May 24 12:49:26 2017

Title
-----
Class FitParameters

Description
-----------
The class FitParameters contains data needed by the fitting algorithm
defined in class AbstractFit


Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""

class FitParameters:
    """This private class contains the parameters needed by the binary
    search fit algorithm defined in AbstractFit, which finds the best
    fit for one of the model parameters given the flux-frequency pairs
    defined in an observation, and leading to the minimum chi-square
    value

    The fit parameters are instance attributes. The required fit
    parameters are the initial guess for the sought model parameter,
    the values providing a guess leading to a negative and a positive
    value for the derivative of chi square, and the factors by which
    these initial guesses are multiplied if they do not satisfy the
    requirement of leading to a negative and a positive value for
    the derivative of chi square.

    There are two optional fit parameters: the minimum and the maximum
    possible values for the sought model parameter
    """

    def __init__(self, initialGuess:float, preGuess:float,
                 postGuess:float, preFactor: float, postFactor:float,
                 min=float('-inf'), max=float('inf')):
        """
        Instantiate an object with the fit patameters
        
        This method just stores the values of all its parameters in 
        instance attributes

        Parameters
        ----------
        self:
            The current object
        initialGuess
            Initial guess for the sought model parameter
        preGuess
            The value of the sought model parameter providing a guess 
            that might lead to a negative value for the derivative of 
            chi square
        postGuess
            The value of the sought model parameter providing a guess 
            that might lead to a positive value for the derivative of 
            chi square
        preFactor
            The factor by which the preGuess value is multiplied if 
            it does not satisfy the requirement of leading to a 
            negative value for the derivative of chi square
        postFactor
            The factor by which the postGuess value is multiplied if 
            it does not satisfy the requirement of leading to a 
            positive value for the derivative of chi square
        min
            The minimum possible value for the sought model parameter
            This is an optional parameter
        max
            The maximum possible value for the sought model parameter
            This is an optional parameter
        """

        self.initialGuess=initialGuess
        self.preGuess=preGuess
        self.postGuess=postGuess
        self.preFactor=preFactor
        self.postFactor=postFactor
        self.min=min
        self.max=max
