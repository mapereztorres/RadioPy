#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Created on Wed May 31 02:34:46 2017

Title
-----
Test Customize

Description
-----------
Welcome to RadioPy! This is an example of application for the package
'radiopy'.  Third of a series of three tutorials, this one explores
the case of defining frequency (GHz) and flux (mJy) arrays just by
typing them into the .py file. The goal is to perform a complete
fitting to the data using the synchrotron self-absorption (SSA)
model. This example was made regarding the case of a single epoch, but
expanding it into a series or sequence of epochs is easy using the
class ObservationSequence (see Documentation of the package).


Metadata
--------
:author: Miguel Glez San Emeterio
:organization: Universidad de Zaragoza
:contact: mglez.sanemeterio@gmail.com
:license: Open source. See LICENSE.txt

"""
# First the imports
import radiopy as rpy
import numpy as np


# ------------------------ DATA ------------------------
# In this example the measurements are typed in the .py file directly 
# (no .CSV file). The data would appear as follows:

# Frequence (GHz)
freq = np.array([1.4,1.8,2.5,3.5,4.9,6.7,
        8.4,13.5,16.0,20.5,25.0,29.0,36.0])

# Flux density (mJy).
flux =np.array([0.719,1.858,4.092,6.188,7.836,6.987,
            6.082,3.790,2.960,2.493,1.819,1.549,1.159])

# Uncertainty on the flux density (mJy).
error = np.array([0.074,0.069,0.083,0.080,0.086,0.077,
                 0.064,0.063,0.067,0.097,0.080,0.053,0.051])

# Age of the SN in days
time = 45.3

# Distance to the event (Mpc)
distance = 8.6
# Error of that distance (Mpc)
distanceError = 0.4



# ------------------------ FITTING ------------------------
# This package was created following the Object Oriented Programming (OOP)
# architechture. Thus the data presented above must be recorded as instances.

# Initialize the fitting class to use the desired model
rpy.SNFit.init(rpy.KraussModel)

# Create an instance of Class Observation. That object will record the data.
observ = rpy.Observation()

# In order to record the data, class Observation has the addPoint method.
# That method is oriented to reading a sequence of data from a CSV file.
# In this case, we must go over the arrays and record the info.
for i in range(0,len(flux)):
    observ.addPoint(freq[i],flux[i],error[i])

# The time (days) can be set using the following method -
observ.setTime(time)

# The distance and its uncertainty (Mpc) have a different treatment in this
# package. They are treated as "Global Data", common to all epochs as it is
# the start date of the event or its name. Thus it is recorded at class
# GlobalData instead of being recorded inside an instance.
rpy.GlobalData.eventDistance = distance
rpy.GlobalData.eventDistanceErr = distanceError


# Now that the Observation instance has recorded the data we proceed
# with the fitting. It is done in two steps. The first one is to
# perform a fitting on the measured data. The second is to use the
# fitting parameters to infer information about the physical
# parameters.

# The fitting is done with the method 'fitEpoch' of class SNFit. This
# method receives an observation as parameter and returns an instance
# of class Result. This instance wil contain several fit values, but
# not the physical information
fitResult = rpy.SNFit.fitEpoch(observ)

# The second step is to infer some physical information from that
# Result. To do it the class SNFit has the method
# "calculatePhysParams". That method receives a result and returns the
# same object with the physical information filled in.
fitResult = rpy.SNFit.calculatePhysParams(fitResult)

# Now calculations are complete and we have an object Observation that
# contains all measuremets and an object Result containing all
# theoretical values, the fitting parameters and the values of the
# three physical magnitudes that this model is capable of
# inferring. All is left is to extract those results, graphically or
# written.

# This method of class SNGraph plots in the iPython console the treated epoch.
rpy.SNGraph.plotEpoch(observ,fitResult)

#Finally we display the numeric results
fitParams = fitResult.getFitting()
fitError = fitResult.getFittingErr()
physParams = fitResult.getPhysParams()
physErr = fitResult.getPhysParamsErr()
print('Time = ',observ.getTime(),' (days)')
print('Distance = ',distance,' +- ',distanceError,' (Mpc)')
print('Fitting parameter p = ',fitParams['p'],' +- ',fitError['pErr'])
print('Fitting parameter st = ',fitParams['st'],' +- ',fitError['stErr'],
      ' (mJy)')
print('Fitting parameter vt = ',fitParams['vt'],' +- ',fitError['vtErr'],
      ' (GHz)')
print(' ')
print('Radious R = ',physParams['r']/1e15,' +- ',physErr['rErr']/1e15,
      ' (1e15 cm)')
print('Magnetic Field B = ',physParams['b'],' +- ',physErr['bErr'],' (G)')
print('Circumstellar wind density A = ',physParams['a'],' +- ',
      physErr['aErr'],' (5e-11 g cm-1)')

# As an alternative to the set of instructions written above, the
# package has its own method to show info on the screen, achieving
# the same outcome. That method is invoked as follows:
# rpy.Report.infoEpoch(fitResult)
